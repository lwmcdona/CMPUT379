#ifndef INCLUDES_HEADER
#define INCLUDES_HEADER

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/resource.h> 
#include <sys/times.h> 
#include <sys/wait.h>
#include <vector>
#include <sstream>
#include <map>

using namespace std;

#endif